# KEM → MiracleCoin v2.0 Deployment Guide
## 50/50 Split with 3-Year Unlock Cycles

---

## 🎉 What Changed

You've upgraded from the original 75/25 split to a **50/50 split with 3-year unlock cycles**. This is MUCH more attractive to early adopters while maintaining fraud protection.

### Old System (v1):
- ❌ 75% locked, 25% immediate
- ❌ Indefinite hold period
- ❌ No expiration mechanism

### New System (v2):
- ✅ 50% immediate, 50% locked
- ✅ Fixed unlock dates (Dec 31 every 3 years)
- ✅ 7-day claim window
- ✅ Redistribution to active traders
- ✅ Weekly trading limits
- ✅ Incentivizes consistency

---

## 📅 The Unlock Schedule

### **Fixed Dates (Everyone Unlocks Together):**

| Unlock Date | Claim Window | Who Gets Unlocked |
|-------------|-------------|-------------------|
| **Dec 31, 2030** | Jan 1-7, 2031 | Everyone who mined before Dec 31, 2027 |
| **Dec 31, 2033** | Jan 1-7, 2034 | Everyone who mined Dec 31, 2027 - Dec 31, 2030 |
| **Dec 31, 2036** | Jan 1-7, 2037 | Everyone who mined Dec 31, 2030 - Dec 31, 2033 |

**Example:** 
- Alice mines on Jan 1, 2025 → Unlocks Dec 31, 2030 (waits 5.9 years)
- Bob mines on Nov 1, 2027 → Also unlocks Dec 31, 2030 (waits 3.1 years)
- Carol mines on Jan 1, 2028 → Unlocks Dec 31, 2033 (waits 5.9 years)

Everyone waits for the next available unlock date that's at least 3 years away.

---

## 🔐 The New Economics

### Mining Flow:
```
User mines 100 KEM ($100 worth) → Claims MiracleCoin

Immediate: 50 MCL (tradeable now, once per week limit)
Locked: 50 MCL (unlocks Dec 31, 2030)
```

### Claim Window (Critical!):
```
Dec 31, 2030 23:59:59 UTC → Unlock happens
Jan 1-7, 2031 → User has 7 DAYS to claim
Jan 8, 2031 → Unclaimed coins → Random redistribution
```

### Redistribution Mechanics:
```
Missed claims → Pool of unclaimed MCL
→ Redistributed to up to 10 random active traders
→ "Active" = traded in last 30 days
→ Split equally among recipients
```

### Weekly Trading Limits:
```
Users can only sell/trade MCL once per week
→ Prevents market dumps
→ Encourages long-term holding
→ Must call recordTrade() before trading
```

---

## 📂 Files You Have

### Smart Contract:
- **`KycGatedMining_v2.sol`** - Updated contract with 50/50 split

### Backend:
- **`kem_miracle_backend.py`** - Updated for 50% split

### Frontend:
- **`kem_claim_portal.html`** - Mining claim interface
- **`miracle_dashboard.html`** - NEW! User dashboard for reserves

---

## 🚀 Deployment Steps

### Step 1: Deploy Smart Contract

```bash
# Using Hardhat (recommended)
npx hardhat run scripts/deploy_v2.js --network polygon

# Save the contract address!
# Example: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb9
```

**Important Configuration:**
```solidity
// After deployment, set these:
contract.setAttestor(YOUR_BACKEND_ATTESTOR_ADDRESS)
contract.setImmediateSplitPercent(50) // Already set to 50 in constructor
```

### Step 2: Set Up Backend

```bash
# Environment variables
export POLYGON_RPC_URL="https://polygon-rpc.com"
export MIRACLE_COIN_ADDRESS="0xYourV2ContractAddress"
export ATTESTOR_PRIVATE_KEY="your-private-key"
export OPENWEATHER_API_KEY="your-api-key"

# Install dependencies
pip install flask web3 eth-account requests --break-system-packages

# Run backend
python kem_miracle_backend.py
# Runs on http://localhost:5000
```

### Step 3: Deploy Frontend

```bash
# Update contract address in both HTML files:
# - kem_claim_portal.html (line ~445)
# - miracle_dashboard.html (line ~237)

const CONTRACT_ADDRESS = '0xYourV2ContractAddress';

# Deploy to your hosting (Netlify, Vercel, etc.)
# Or run locally:
python -m http.server 8000
```

---

## 👥 User Experience

### For Early Miners (Mining Now):

**Timeline:**
```
Today (2025) → Mine KEM → Get 50% MCL now
↓ (5.9 years wait)
Dec 31, 2030 → Other 50% unlocks
Jan 1-7, 2031 → Claim window (7 days)
Jan 8, 2031 → If not claimed → Redistributed
```

**What They Get:**
- Immediate liquid 50% (can trade weekly)
- Long wait but predictable unlock date
- Warning system (dashboard shows countdown)
- Risk of loss if they forget to claim

### For Late Miners (Mining in 2027):

**Timeline:**
```
Nov 2027 → Mine KEM → Get 50% MCL now
↓ (3.1 years wait)
Dec 31, 2030 → Other 50% unlocks
```

**Advantage:**
- Same 50% immediate
- Shorter wait time!
- Gets to unlock with early miners

---

## 📊 User Dashboard Features

The new `miracle_dashboard.html` shows:

1. **Balance Overview**
   - Available (liquid)
   - Claimable (unlocked but not claimed)
   - Locked (future unlocks)
   - Total value

2. **Trading Status**
   - Can trade now? (green/yellow indicator)
   - Cooldown remaining
   - Record trade button

3. **Reserve Entries**
   - Each mining session listed separately
   - Unlock date countdown
   - Claim deadline
   - Status (locked/claimable/expired)

4. **Countdown Timer**
   - Live countdown to next unlock
   - Real-time updates

---

## 🔧 Smart Contract Functions

### User Functions:

```solidity
// Claim new MCL (50/50 split)
function claim(Permit calldata p, bytes calldata sig)

// Claim unlocked reserves (after Dec 31, 2030)
function claimReserves()

// Record a trade (must do before trading)
function recordTrade(address trader)
```

### View Functions:

```solidity
// Check claimable, expired, and locked amounts
function getClaimableReserves(address user) 
    returns (uint256 claimable, uint256 expired, uint256 locked)

// Get all reserve entries for user
function getUserReserves(address user) 
    returns (ReserveEntry[] memory)

// Check if user can trade
function canTrade(address trader) 
    returns (bool)

// Get next unlock date
function getNextUnlockDate() 
    returns (uint256)
```

### Admin Functions:

```solidity
// Redistribute unclaimed coins
function redistributeUnclaimed()

// Clean up inactive traders list
function cleanupInactiveTraders()

// Set attestor address
function setAttestor(address a)
```

---

## ⚠️ Critical Warnings for Users

### You MUST Show Users:

```
⚠️ CRITICAL: You have 7 days to claim after unlock!

Your 50 MCL unlocks on Dec 31, 2030
You must claim between Jan 1-7, 2031
If you miss this window, your coins are GONE

→ Set a calendar reminder NOW
→ Check the dashboard in late December 2030
→ Don't lose your coins!
```

### Email/SMS Reminders:

Consider implementing:
- 30 days before unlock: "Your MCL unlocks soon!"
- 7 days before unlock: "Get ready to claim"
- Day of unlock: "CLAIM NOW! Window is open"
- Day 5 of window: "2 days left to claim!"
- Day 7: "LAST DAY TO CLAIM!"

---

## 🎮 Game Theory & Incentives

### What Makes This System Brilliant:

1. **50/50 Split**
   - More attractive than 25% immediate
   - Users have "skin in the game" right away
   - Can start trading/using immediately

2. **Fixed Unlock Dates**
   - No confusion about when to claim
   - Everyone waits together (community building)
   - Creates "unlock day" events

3. **7-Day Window**
   - Not too short (reasonable time)
   - Not too long (creates urgency)
   - Forces user engagement

4. **Redistribution**
   - Punishes inactive users
   - Rewards active traders
   - Reduces supply (unclaimed coins go to engaged users)
   - Creates scarcity

5. **Weekly Trading Limits**
   - Prevents panic selling
   - Encourages strategic planning
   - Reduces market volatility
   - Increases holder conviction

---

## 📈 Expected Behaviors

### Good Behaviors (Incentivized):

- ✅ Mine consistently
- ✅ Trade strategically (once per week)
- ✅ Set calendar reminders
- ✅ Check dashboard regularly
- ✅ Stay engaged with community

### Bad Behaviors (Punished):

- ❌ Mine and forget → Lose 50%
- ❌ Try to dump all at once → Weekly limit blocks
- ❌ Miss claim window → Coins redistributed
- ❌ Go inactive → Don't get redistribution bonuses

---

## 🧪 Testing Checklist

### Before Mainnet Launch:

- [ ] Deploy to Polygon Mumbai testnet
- [ ] Test mining claim (verify 50/50 split)
- [ ] Test unlock date calculation (should return Dec 31, 2030)
- [ ] Test claim window (7-day period works)
- [ ] Test redistribution (unclaimed coins distributed)
- [ ] Test weekly trading limit (can't trade twice in 7 days)
- [ ] Test active trader tracking (added/removed correctly)
- [ ] Load test backend (100 concurrent requests)
- [ ] UI/UX testing with real users
- [ ] Security audit (especially redistribution logic)

### Test Scenarios:

```javascript
// Scenario 1: Normal claim
- Mine KEM → Upload → Claim → Verify 50% immediate, 50% locked

// Scenario 2: Try to claim twice with same token
- Should fail with "replay" error

// Scenario 3: Wait until unlock and claim
- Fast-forward to Dec 31, 2030 (in testnet)
- Call claimReserves() → Should receive 50%

// Scenario 4: Miss claim window
- Fast-forward to Jan 8, 2031
- Call claimReserves() → Should fail or add to redistribution

// Scenario 5: Weekly trading limit
- Record trade → Try again same day → Should fail
- Wait 7 days → Try again → Should succeed
```

---

## 🔒 Security Considerations

### Redistribution Attack Vectors:

**Potential Issue:** Could someone game the redistribution?

**Mitigations:**
1. Only "active traders" qualify (traded in last 30 days)
2. Random selection (not predictable)
3. Max 10 recipients per redistribution
4. Requires calling `redistributeUnclaimed()` (can't be automated maliciously)

### Sybil Attack:

**Potential Issue:** Create 100 accounts, mine small amounts, increase redistribution chances?

**Mitigations:**
1. KYC requirement (one identity per account)
2. Gas costs make this expensive
3. Must actively trade (weekly) to stay in pool
4. Random selection reduces advantage

### Front-Running:

**Potential Issue:** See redistribution transaction, quickly trade to become "active"?

**Mitigations:**
1. 30-day activity window (can't game last-minute)
2. Must have traded BEFORE unclaimed coins expire
3. Random selection limits predictability

---

## 📞 User Support FAQs

### Q: When does my locked portion unlock?
**A:** Dec 31, 2030 if you mined before Dec 31, 2027. Check dashboard for your specific date.

### Q: What happens if I miss the 7-day window?
**A:** Your coins are permanently redistributed to active traders. You cannot recover them.

### Q: Can I trade my immediate 50% anytime?
**A:** You can trade on exchanges once per week. You must call `recordTrade()` before each trade.

### Q: Can I transfer to a friend without the weekly limit?
**A:** No, ALL transfers (including to friends) count as trades and have the weekly limit.

### Q: What if I mine multiple times?
**A:** Each mining session creates a separate reserve entry with its own unlock date.

### Q: Can I unlock early for emergencies?
**A:** No, the 3-year lock is absolute. Plan accordingly.

### Q: Who gets my coins if I don't claim?
**A:** Up to 10 random active traders split them equally.

---

## 🚨 Emergency Procedures

### If Users Report Claim Issues:

1. **Check unlock date:**
   ```solidity
   contract.getUserReserves(userAddress)
   // Verify unlockDate has passed
   ```

2. **Check claim deadline:**
   ```solidity
   // Verify current time < claimDeadline
   ```

3. **Check if already claimed:**
   ```solidity
   // Look at claimed boolean
   ```

4. **Check gas/network issues:**
   - Polygon congestion?
   - User has enough MATIC for gas?

### If Redistribution Fails:

```solidity
// Check pending redistribution amount
contract.pendingRedistribution()

// Check active traders
contract.getActiveTraderCount()

// Manual redistribution
contract.redistributeUnclaimed() // Anyone can call
```

---

## 📊 Monitoring & Analytics

### Key Metrics to Track:

```sql
-- Total MCL minted via KEM
SELECT SUM(immediate_amount + reserve_amount) FROM claims;

-- Unclaimed coins (potential loss)
SELECT SUM(amount) FROM reserves 
WHERE unlocked = true 
  AND claimed = false 
  AND deadline_passed = true;

-- Active trader count
SELECT COUNT(*) FROM active_traders 
WHERE last_trade > NOW() - INTERVAL '30 days';

-- Claim success rate
SELECT 
    COUNT(CASE WHEN claimed THEN 1 END) * 100.0 / COUNT(*) 
FROM reserves 
WHERE unlocked = true;
```

### Alerts to Set Up:

- 🚨 Unlock date approaching (30 days out)
- 🚨 Claim window open (send user emails)
- 🚨 Redistribution pending (>1000 MCL unclaimed)
- 🚨 Low active trader count (<10 traders)
- 🚨 Suspicious trading patterns

---

## 🎯 Success Metrics

### What Good Looks Like:

| Metric | Target | Why |
|--------|--------|-----|
| Claim success rate | >80% | Users are engaged |
| Active traders | >100 | Healthy ecosystem |
| Weekly trade volume | Steady | No pump/dump |
| Redistribution events | <20% of unlocks | Most users claim |
| User retention | >60% after 1 year | Sticky product |

---

## 🔄 Next Steps

1. **Deploy v2 contract to Mumbai testnet**
2. **Test all functions thoroughly**
3. **Run security audit**
4. **Deploy to Polygon mainnet**
5. **Update all frontend references**
6. **Launch marketing campaign**
7. **Set up monitoring/alerts**
8. **Prepare for Dec 31, 2030 unlock event**

---

## 📞 Support

For technical issues:
- Check smart contract events
- Review backend logs
- Test on Mumbai first
- Consult dashboard for user-specific data

**Good luck with your launch! This tokenomics design is innovative and has strong incentive alignment.** 🚀
