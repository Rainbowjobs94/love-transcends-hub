#!/usr/bin/env python3
"""
KEM-to-MiracleCoin Integration Backend
Connects keystroke mining to your existing KycGatedMining smart contract
"""

from flask import Flask, request, jsonify
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_structured_data
import hashlib
import json
import time
import requests
from datetime import datetime
import os

app = Flask(__name__)

# ============================================================================
# CONFIGURATION
# ============================================================================

# Blockchain Configuration
POLYGON_RPC_URL = os.getenv("POLYGON_RPC_URL", "https://polygon-rpc.com")
MIRACLE_COIN_CONTRACT_ADDRESS = os.getenv("MIRACLE_COIN_ADDRESS")
ATTESTOR_PRIVATE_KEY = os.getenv("ATTESTOR_PRIVATE_KEY")  # Your attestor key

# Weather API (for UV verification)
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")

# Mining Rate Configuration
KEM_TO_USD_BASE_RATE = 1.0  # 1 KEM = $1 USD (from your token economics)
KEYSTROKE_MINING_ENABLED = True

# Fraud Detection Thresholds
MIN_SESSION_DURATION = 60  # Minimum 1 minute of typing
MIN_EFFICIENCY = 0.15  # At least 15% of keystrokes must be valid
MAX_DAILY_CLAIMS = 5  # Max claims per day per user

# Split Configuration (50/50 instead of 75/25)
IMMEDIATE_SPLIT_PERCENT = 50  # User gets 50% immediately
RESERVE_SPLIT_PERCENT = 50  # 50% locked for 3 years

# ============================================================================
# WEB3 SETUP
# ============================================================================

web3 = Web3(Web3.HTTPProvider(POLYGON_RPC_URL))
attestor_account = Account.from_key(ATTESTOR_PRIVATE_KEY)

print(f"✓ Attestor Address: {attestor_account.address}")
print(f"✓ Connected to Polygon: {web3.is_connected()}")

# ============================================================================
# KEM TOKEN VERIFICATION
# ============================================================================

def verify_kem_token(token_data):
    """Verify a KEM token's authenticity and calculate claimable amount"""
    
    # 1. Verify signature
    try:
        token_copy = token_data.copy()
        signature = token_copy.pop('signature', None)
        if not signature:
            return False, "Missing signature"
        
        expected_sig = hashlib.sha256(
            json.dumps(token_copy, sort_keys=True).encode()
        ).hexdigest()
        
        if signature != expected_sig:
            return False, "Invalid signature"
    except Exception as e:
        return False, f"Signature verification failed: {str(e)}"
    
    # 2. Verify token data structure
    required_fields = ['session_id', 'device_fingerprint', 'valid_work_units', 
                       'coin_value', 'session_duration', 'difficulty']
    token_info = token_data.get('token_data', {})
    
    for field in required_fields:
        if field not in token_info:
            return False, f"Missing field: {field}"
    
    # 3. Verify proof chain
    proof_chain = token_data.get('proof_chain', [])
    difficulty = token_info['difficulty']
    
    for proof in proof_chain:
        block_hash = proof.get('hash', '')
        if not block_hash.startswith('0' * difficulty):
            return False, "Invalid proof of work"
    
    # 4. Fraud detection checks
    total_keystrokes = token_info.get('total_keystrokes', 0)
    valid_work = token_info.get('valid_work_units', 0)
    session_duration = token_info.get('session_duration', 0)
    
    if session_duration < MIN_SESSION_DURATION:
        return False, f"Session too short (min {MIN_SESSION_DURATION}s)"
    
    efficiency = valid_work / max(total_keystrokes, 1)
    if efficiency < MIN_EFFICIENCY:
        return False, f"Efficiency too low: {efficiency*100:.1f}% (min {MIN_EFFICIENCY*100}%)"
    
    # 5. Calculate claimable USD amount
    kem_value = token_info['coin_value']
    usd_amount = kem_value * KEM_TO_USD_BASE_RATE
    
    return True, {
        'kem_value': kem_value,
        'usd_amount': usd_amount,
        'session_id': token_info['session_id'],
        'device_fingerprint': token_info['device_fingerprint'],
        'efficiency': efficiency,
        'duration_minutes': session_duration / 60
    }


def get_uv_index(lat, lon):
    """Fetch current UV index from OpenWeather API"""
    try:
        url = f"http://api.openweathermap.org/data/2.5/uvi?lat={lat}&lon={lon}&appid={OPENWEATHER_API_KEY}"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        return int(data.get('value', 0) * 10)  # Times 10 as per your contract
    except Exception as e:
        print(f"UV fetch error: {e}")
        return 0  # Default to 0 if API fails


# ============================================================================
# EIP-712 PERMIT SIGNING
# ============================================================================

def create_and_sign_permit(user_address, kem_token_data, kyc_hash, geo_data):
    """
    Create and sign a permit for the KycGatedMining contract
    This matches your Solidity struct exactly:
    
    struct Permit{
        address user; 
        bytes32 kycHash; 
        int32 latE7; 
        int32 lonE7; 
        uint64 unixTime;
        uint16 compassDeg; 
        uint16 uvTimes10; 
        uint32 lux; 
        uint256 amount;
    }
    """
    
    # Convert USD to MiracleCoin wei (18 decimals)
    usd_amount = kem_token_data['usd_amount']
    amount_wei = int(usd_amount * 10**18)
    
    # Prepare permit data
    permit = {
        'user': web3.to_checksum_address(user_address),
        'kycHash': kyc_hash,  # bytes32
        'latE7': int(geo_data['latitude'] * 1e7),  # lat * 10^7
        'lonE7': int(geo_data['longitude'] * 1e7),  # lon * 10^7
        'unixTime': int(time.time()),
        'compassDeg': int(geo_data.get('compass_heading', 0)),
        'uvTimes10': geo_data.get('uv_index', 0),
        'lux': int(geo_data.get('ambient_light', 1000)),
        'amount': amount_wei
    }
    
    # EIP-712 domain
    domain = {
        'name': 'MiracleMining',
        'version': '1',
        'chainId': 137,  # Polygon Mainnet (use 80001 for Mumbai testnet)
        'verifyingContract': MIRACLE_COIN_CONTRACT_ADDRESS
    }
    
    # EIP-712 types
    types = {
        'EIP712Domain': [
            {'name': 'name', 'type': 'string'},
            {'name': 'version', 'type': 'string'},
            {'name': 'chainId', 'type': 'uint256'},
            {'name': 'verifyingContract', 'type': 'address'}
        ],
        'Permit': [
            {'name': 'user', 'type': 'address'},
            {'name': 'kycHash', 'type': 'bytes32'},
            {'name': 'latE7', 'type': 'int32'},
            {'name': 'lonE7', 'type': 'int32'},
            {'name': 'unixTime', 'type': 'uint64'},
            {'name': 'compassDeg', 'type': 'uint16'},
            {'name': 'uvTimes10', 'type': 'uint16'},
            {'name': 'lux', 'type': 'uint32'},
            {'name': 'amount', 'type': 'uint256'}
        ]
    }
    
    # Create structured data
    structured_data = {
        'types': types,
        'primaryType': 'Permit',
        'domain': domain,
        'message': permit
    }
    
    # Sign with attestor key
    encoded_data = encode_structured_data(structured_data)
    signed = attestor_account.sign_message(encoded_data)
    
    return permit, signed.signature.hex()


# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.route('/api/kem/verify', methods=['POST'])
def verify_kem_endpoint():
    """
    Verify a KEM token without claiming
    Used by users to check if their token is valid
    """
    try:
        token_data = request.get_json()
        
        valid, result = verify_kem_token(token_data)
        
        if not valid:
            return jsonify({
                'success': False,
                'error': result
            }), 400
        
        return jsonify({
            'success': True,
            'verified': True,
            'kem_value': result['kem_value'],
            'claimable_usd': result['usd_amount'],
            'efficiency': f"{result['efficiency']*100:.1f}%",
            'session_duration_minutes': result['duration_minutes']
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/kem/claim', methods=['POST'])
def claim_kem_endpoint():
    """
    Claim a KEM token and receive MiracleCoin
    
    Required payload:
    {
        "token_data": {...},  // Your KEM token JSON
        "user_address": "0x...",  // User's wallet address
        "kyc_hash": "0x...",  // KYC verification hash
        "geo_data": {
            "latitude": 49.2827,
            "longitude": -123.1207,
            "compass_heading": 270,
            "ambient_light": 500
        }
    }
    """
    try:
        data = request.get_json()
        
        # Extract data
        token_data = data.get('token_data')
        user_address = data.get('user_address')
        kyc_hash = data.get('kyc_hash')
        geo_data = data.get('geo_data', {})
        
        # Validate inputs
        if not all([token_data, user_address, kyc_hash, geo_data]):
            return jsonify({
                'success': False,
                'error': 'Missing required fields'
            }), 400
        
        # 1. Verify KEM token
        valid, result = verify_kem_token(token_data)
        if not valid:
            return jsonify({
                'success': False,
                'error': f'Token verification failed: {result}'
            }), 400
        
        # 2. Verify UV index matches location
        lat = geo_data.get('latitude')
        lon = geo_data.get('longitude')
        
        if lat and lon:
            uv_index = get_uv_index(lat, lon)
            geo_data['uv_index'] = uv_index
        else:
            return jsonify({
                'success': False,
                'error': 'Missing latitude/longitude'
            }), 400
        
        # 3. Create and sign permit
        permit, signature = create_and_sign_permit(
            user_address, 
            result, 
            kyc_hash, 
            geo_data
        )
        
        # 4. Return permit and signature for user to submit on-chain
        return jsonify({
            'success': True,
            'verified': True,
            'permit': permit,
            'signature': signature,
            'contract_address': MIRACLE_COIN_CONTRACT_ADDRESS,
            'claim_info': {
                'kem_value': result['kem_value'],
                'usd_amount': result['usd_amount'],
                'miracle_coin_amount': permit['amount'] / 10**18,
                'immediate_percent': IMMEDIATE_SPLIT_PERCENT,
                'reserve_percent': RESERVE_SPLIT_PERCENT,
                'user_receives_now': permit['amount'] * (IMMEDIATE_SPLIT_PERCENT/100) / 10**18,
                'locked_3years': permit['amount'] * (RESERVE_SPLIT_PERCENT/100) / 10**18,
                'unlock_date': 'December 31, 2030',
                'claim_window': '7 days (January 1-7, 2031)'
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/kem/claim-direct', methods=['POST'])
def claim_kem_direct():
    """
    Direct claim - backend submits transaction on behalf of user
    (Less decentralized but simpler UX)
    """
    try:
        data = request.get_json()
        
        token_data = data.get('token_data')
        user_address = data.get('user_address')
        kyc_hash = data.get('kyc_hash')
        geo_data = data.get('geo_data', {})
        
        # Same verification as above
        valid, result = verify_kem_token(token_data)
        if not valid:
            return jsonify({'success': False, 'error': result}), 400
        
        # Get UV index
        lat = geo_data.get('latitude')
        lon = geo_data.get('longitude')
        if lat and lon:
            geo_data['uv_index'] = get_uv_index(lat, lon)
        
        # Create permit and signature
        permit, signature = create_and_sign_permit(
            user_address, result, kyc_hash, geo_data
        )
        
        # Submit transaction on-chain
        # (You'd need the contract ABI and gas configuration here)
        # This is a placeholder for the actual transaction submission
        
        return jsonify({
            'success': True,
            'message': 'Claim submitted on-chain',
            'tx_hash': '0x...',  # Would be real tx hash
            'miracle_coin_minted': permit['amount'] / 10**18
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'attestor': attestor_account.address,
        'blockchain_connected': web3.is_connected(),
        'keystroke_mining_enabled': KEYSTROKE_MINING_ENABLED
    }), 200


# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    print("\n" + "="*70)
    print("KEM → MiracleCoin Integration Backend")
    print("="*70)
    print(f"\n✓ Attestor: {attestor_account.address}")
    print(f"✓ Contract: {MIRACLE_COIN_CONTRACT_ADDRESS}")
    print(f"✓ KEM Rate: {KEM_TO_USD_BASE_RATE} USD per KEM")
    print(f"\n🚀 Server starting on http://localhost:5000")
    print("="*70 + "\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
